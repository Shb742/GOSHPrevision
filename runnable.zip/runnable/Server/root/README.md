# GOSHPrevision
This is the repository for the GOSH-Prevision course work, by Team 9 at UCL.

# How To Run The Code
The code must be run on a server or the browser is likely to block it from loading assets (<a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS">CORS</a> errors).
<br><br>
You may use any http server, just have the project in the root directory.<br>
If the server is on the machine it'll likely be accessible through 127.0.0.1 or localhost

We used <a href="https://github.com/Shb743/HT-PY">this</a> server when testing.
