# HT&PY
HT&PY is an simple HTTP & HTTPS web-server written in Python from ground up.

It allows complete customisation of the server to suit a range of requirements.

Comes with server side language support for Python.


# Pre-Requisites
The server does not need any pre-requisites other than python 2.7 with the standard libraries.

For HTTPS support Open-SSL is required (with python version 2.7.9 or greater).

*Note: I have not tested the server on windows.


# How to run the server
The server should be given sufficient permissions if it is to bind to reserved ports i.e:80

Server can be started like so "python Server.py".